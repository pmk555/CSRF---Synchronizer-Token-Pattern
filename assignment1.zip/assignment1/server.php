<?php

	//session start
	session_start();

	//generate a token by function
	generateToken();


function generateToken(){

	if(empty($_SESSION['key']))
	{
		//generate a session key by converting random binaries to hex
		$_SESSION['key'] = bin2hex(random_bytes(32));
	}

	//Generate token by SHA256 Encryption,custom name and the session key
	$token = hash_hmac('sha256', 'login_csrf_token', $_SESSION['key']);

	//Initialize generated token in session variable
	$_SESSION['server_csrf'] = $token;

	//store key in memory buffer
	ob_start();

	echo $token;
}

if(isset($_POST['submit']))
	{
		//clear memory buffer records
		ob_end_clean();
		
		//call POST variables for validation function
		validate($_POST['user'],$_POST['pwd'],$_POST['csrf'],$_COOKIE['log_in']);


	}
	

//validate function

function validate($username, $password, $user_csrf, $user_sessionCookie)
{
	if($username == "Admin" && $password == "Lizzie")
	{
		

		//validating csrf token with the cookie
		if( $user_csrf == $_SESSION['server_csrf'] && $user_sessionCookie == session_id())
		{
			
			header("Location:index.html");
		}
		else
		{
			echo "CSRF Failure"."<br/>";
			echo "User Token : ".$user_csrf."<br/>";
			echo "Server Token :".$_SESSION['server_csrf']."<br/>"; 
			exit();
		}
	}
	else
	{
			echo "<script> alert('Invalid Username or Password') </script>"; 
						
           
			header("Location:login.php");
	}
	

}	

?>




